using OrchardCore.DisplayManagement.Shapes;

namespace OrchardCMS.Models
{
    public class TestContentPartAShape : Shape
    {
        public string Line { get; set; }
    }
}

