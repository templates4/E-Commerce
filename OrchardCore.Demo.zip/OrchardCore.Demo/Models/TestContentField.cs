using OrchardCore.ContentManagement;

namespace OrchardCMS.Models
{
    public class TestContentField : ContentField
    {
        public string Text;
    }
}

