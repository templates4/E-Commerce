namespace OrchardCMS.Models
{
    public class FakeShape
    {
        public string Value { get; set; }
    }
}

