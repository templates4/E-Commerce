using OrchardCore.DisplayManagement.Views;

namespace OrchardCMS.Models
{
    public class CustomViewModel : ShapeViewModel
    {
        public string Value { get; set; }
    }
}

