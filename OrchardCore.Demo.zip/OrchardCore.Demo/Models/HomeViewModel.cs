namespace OrchardCMS.Models
{
    public class HomeViewModel
    {
        public string Text { get; set; }
        public dynamic Foo { get; set; }
    }
}

